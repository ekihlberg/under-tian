<form class="search" role="search" method="get" action="<?php echo home_url( '/' ); ?>" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" >
  <input type="search" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="false" class="form-control" value="<?php echo get_search_query() ?>" name="s" title="Search" />
</form>
